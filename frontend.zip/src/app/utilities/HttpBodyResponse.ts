export interface HttpBodyResponse{

    status: string;
    error: string ;
    response :any;
}