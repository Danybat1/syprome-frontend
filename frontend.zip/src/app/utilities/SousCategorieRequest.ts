export class SousCategorieRequest{
    constructor( public id:number | null,public intitule:string,public categorie: number) {}
}