export class Utils{
    public static apiURL:string ="http://localhost:8080";
    public static otpApiUrl:string="http://10.25.3.81:5002";
    constructor () {}
}