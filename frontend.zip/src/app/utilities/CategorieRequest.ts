export class CategorieRequest{
    constructor( public id:number | null,public intitule:string,public menu: number) {}
}