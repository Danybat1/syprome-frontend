export class Menu {
    public id:number | undefined;
    public description:string ="";
   
}