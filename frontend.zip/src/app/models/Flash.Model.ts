export class Flash{
public id :number |null =0;
public intitule :string ="";
public date :string ="";
public debut : string ="";
public fin : string ="";
        constructor() {
            
        }
}