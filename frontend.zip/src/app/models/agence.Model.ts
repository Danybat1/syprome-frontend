

export class Agence {
    public id:number =0;
    public intitule:string ="";
}