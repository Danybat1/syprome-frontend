import { Categorie } from "./Categorie.Model";

export class SousCategorie{
    public id:number =0;
    public intitule:string ="";
}