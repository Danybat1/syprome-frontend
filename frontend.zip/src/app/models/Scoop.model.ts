export class Scoop{
    public id: number=0;
    public contenu: string="";

    constructor() {}
}