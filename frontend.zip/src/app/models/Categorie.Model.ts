import { Menu } from "./Menu.model";

export class Categorie {
    public id:number =0;
    public description:string ="";
    public menu: Menu=new Menu
}