export class Role {
    public id: number=0;
    public description :string="";
    constructor() {}
}